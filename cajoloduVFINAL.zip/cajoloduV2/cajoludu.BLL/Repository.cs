﻿using cajoludu.MODEL;

namespace cajoludu.BLL
{
    public class Repository
    {
        private static List<Livro> livrosFavoritos = new List<Livro>();
        public static void AddLivro(Livro _livro)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                dbContext.Add(_livro);
                dbContext.SaveChanges();
            }
        }

        public static void AddUsuario(Usuario _usuario)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                dbContext.Add(_usuario);
                dbContext.SaveChanges();
            }
        }

        public static Livro GetBookByName(string nome)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                var liv = dbContext.Livros.Single(l => l.Titulo == nome);
                return liv;
            }
        }

        public static Usuario GetUserByEmail(string email)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                var use = dbContext.Usuarios.Single(u => u.Email == email);
                return use;
            }
        }

        public static List<Livro> GetAll()
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                var liv = dbContext.Livros.ToList();
                return liv;
            }
        }

        public static void AdicionarLivroFavorito(Livro _livro)
        {
            if (!IsLivroFavorito(_livro))
            {
                livrosFavoritos.Add(_livro);
            }
        }

        public static void RemoverLivroFavorito(Livro _livro)
        {
            if (IsLivroFavorito(_livro))
            {
                livrosFavoritos.Remove(_livro);
            }
        }

        public static bool IsLivroFavorito(Livro _livro)
        {
            return livrosFavoritos.Contains(_livro);
        }


        public static void UpdateLivro(Livro _livro)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                var liv = dbContext.Livros.Single(l => l.Titulo == _livro.Titulo);
                liv.Titulo = _livro.Titulo;
                liv.Autor = _livro.Autor;
                liv.Descricao = _livro.Descricao;
                dbContext.SaveChanges();
            }
        }

        public static void UpdateUsuario(Usuario _usuario)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                var use = dbContext.Usuarios.Single(u => u.Nome == _usuario.Nome);
                use.Nome = _usuario.Nome;
                use.Email = _usuario.Email;
                use.Senha = _usuario.Senha;
                dbContext.SaveChanges();
            }
        }

        public static void ExcluirLivro(Livro _livro)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                var liv = dbContext.Livros.Single(l => l.Titulo == _livro.Titulo);
                dbContext.Remove(liv);
                dbContext.SaveChanges();
            }
        }

        public static void ExcluirUsuario(Usuario _usuario)
        {
            using (var dbContext = new CUsersGuilhermeSourceReposCajoloduv2CajoluduDalDatabaseDatabase1MdfContext())
            {
                var use = dbContext.Usuarios.Single(u => u.Nome == _usuario.Nome);
                dbContext.Remove(use);
                dbContext.SaveChanges();
            }
        }
    }
}