﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Windows.Forms;
using cajoludu.BLL;
using cajoludu.MODEL;

namespace cajoludu.APPv2
{
    public partial class Form5 : Form
    {
        private const string apiUrl = "https://www.googleapis.com/books/v1/volumes?q=";

        public Form5()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            listView1.Columns.Add("Título");
            listView1.Columns.Add("Autor");
            listView1.Columns.Add("Descrição");
            listView1.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.ColumnContent);
            listView1.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);
            listView1.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.ColumnContent);
            listView1.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize);
            listView1.AutoResizeColumn(2, ColumnHeaderAutoResizeStyle.ColumnContent);
            listView1.AutoResizeColumn(2, ColumnHeaderAutoResizeStyle.HeaderSize);
            listView1.CheckBoxes = true;
            listView2.Columns.Add("Título");
            listView2.Columns.Add("Autor");
            listView2.Columns.Add("Descrição");
            listView2.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.ColumnContent);
            listView2.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);
            listView2.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.ColumnContent);
            listView2.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize);
            listView2.AutoResizeColumn(2, ColumnHeaderAutoResizeStyle.ColumnContent);
            listView2.AutoResizeColumn(2, ColumnHeaderAutoResizeStyle.HeaderSize);
            listView2.CheckBoxes = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 f = new Form4();
            f.Show();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public class ResultadoPesquisa
        {
            public List<Item> items { get; set; }
        }

        public class Item
        {
            public VolumeInfo volumeInfo { get; set; }
        }
        public class VolumeInfo
        {
            public string title { get; set; }
            public List<string> authors { get; set; }
            public string description { get; set; }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            await CarregarLivrosAsync();
        }

        private async Task CarregarLivrosAsync()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string url = apiUrl + textBox1.Text;
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    ResultadoPesquisa resultado = JsonSerializer.Deserialize<ResultadoPesquisa>(json);


                    if (resultado != null && resultado.items != null)
                    {
                        foreach (Item item in resultado.items)
                        {
                            Livro livro = new Livro();
                            livro.Titulo = item.volumeInfo.title;
                            livro.Autor = string.Join(", ", item.volumeInfo.authors);
                            livro.Descricao = item.volumeInfo.description;
                            Repository.AddLivro(livro);
                        }

                        ExibirLivros();
                    }
                    else
                    {
                        MessageBox.Show("Nenhum livro encontrado.", "Pesquisa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar os livros: " + ex.InnerException?.Message ?? ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExibirLivros()
        {
            // Limpar o ListView antes de exibir os livros
            listView1.Items.Clear();

            // Exibir os livros no ListView
            foreach (Livro livro in Repository.GetAll())
            {
                ListViewItem item = new ListViewItem(livro.Titulo);
                item.SubItems.Add(livro.Autor);
                item.SubItems.Add(livro.Descricao);
                listView1.Items.Add(item);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        List<Livro> livrosFavoritos = new List<Livro>();
        private void button2_Click(object sender, EventArgs e)
        {
            listView2.Items.Clear();

            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Checked)
                {
                    Livro livro = new Livro();
                    livro.Titulo = item.SubItems[0].Text;
                    livro.Autor = item.SubItems[1].Text;
                    livro.Descricao = item.SubItems[2].Text;
                    livrosFavoritos.Add(livro);
                    ListViewItem novoItem = new ListViewItem(livro.Titulo);
                    novoItem.SubItems.Add(livro.Autor);
                    novoItem.SubItems.Add(livro.Descricao);
                    listView2.Items.Add(novoItem);
                }
            }

            MessageBox.Show("Livros favoritados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            List<ListViewItem> itensRemover = new List<ListViewItem>();

            foreach (ListViewItem item in listView2.Items)
            {
                if (item.Checked)
                {
                    Livro livro = new Livro();
                    livro.Titulo = item.SubItems[0].Text;
                    livro.Autor = item.SubItems[1].Text;
                    livro.Descricao = item.SubItems[2].Text;
                    livrosFavoritos.Remove(livro);
                    itensRemover.Add(item);
                }
            }

            foreach (ListViewItem item in itensRemover)
            {
                listView2.Items.Remove(item);
            }

            MessageBox.Show("Livros desfavoritados com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
