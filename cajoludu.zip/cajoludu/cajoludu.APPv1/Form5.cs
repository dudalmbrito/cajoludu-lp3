﻿using cajoludu.BLL;
using cajoludu.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace cajoludu.APPv1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 f = new Form4();
            f.Show();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listView1.Items.Clear();

            try
            {
                List<Livro> lista = Repository.GetAll();
                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    ListViewItem item = listView1.Items[i];

                    string subItem1 = item.SubItems[0].Text;
                    string subItem2 = item.SubItems[1].Text;

                    Console.WriteLine("Item " + i + ": " + subItem1 + ", " + subItem2);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao mostrar a lista: " + ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*Livro l = new Livro();
            l.Titulo = textBox1.Text;
            l.Autor = textBox2.Text;
            l.Descricao = textBox3.Text;
            Repository.AddLivro(l);
            MessageBox.Show("Livros cadastrados com sucesso!");*/
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
