using cajoludu.MODEL;
using cajoludu.BLL;

namespace cajoludu.APPv1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario u = new Usuario();
                u.Nome = textBox1.Text;
                u.Email = textBox2.Text;
                u.Senha = textBox3.Text;
                Repository.AddUsuario(u);
                MessageBox.Show("Usu�rio cadastrado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao cadastrar o usu�rio: " + ex.InnerException?.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario u = Repository.GetUserByEmail(textBox4.Text);

                if (u != null)
                {
                    if (u.Senha == textBox5.Text)
                    {
                        u.Email = textBox4.Text;
                        u.Senha = textBox5.Text;
                        MessageBox.Show("Usu�rio encontrado com sucesso!");
                        this.Hide();
                        Form2 f = new Form2();
                        f.Show();
                    }
                    else
                    {
                        MessageBox.Show("Senha incorreta!");
                    }
                }
                else
                {
                    MessageBox.Show("Usu�rio n�o encontrado!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao buscar o usu�rio: " + ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}