﻿select * from livro;
