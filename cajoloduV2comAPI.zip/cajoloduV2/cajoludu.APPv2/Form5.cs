﻿using cajoludu.BLL;
using cajoludu.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Text.Json;

namespace cajoludu.APPv2
{
    public partial class Form5 : Form
    {
        private const string apiUrl = "https://api.example.com/books";
        public Form5()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private async void Form5_Load(object sender, EventArgs e)
        {
            await CarregarLivrosAsync();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Form4 f = new Form4();
            f.Show();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*Livro l = new Livro();
            l.Titulo = textBox1.Text;
            l.Autor = textBox2.Text;
            l.Descricao = textBox3.Text;
            Repository.AddLivro(l);
            MessageBox.Show("Livros cadastrados com sucesso!");*/
        }

        private async Task CarregarLivrosAsync()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    List<Livro> livro = JsonSerializer.Deserialize<List<Livro>>(json);

                    foreach (Livro l in livro)
                    {
                        ListViewItem item = new ListViewItem(l.Titulo);
                        item.SubItems.Add(l.Autor);
                        item.SubItems.Add(l.Descricao);
                        listView1.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar os livros: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
