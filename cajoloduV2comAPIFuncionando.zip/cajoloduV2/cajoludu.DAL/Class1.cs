﻿namespace cajoludu.DAL
{
    public class Class1
    {

    }
}