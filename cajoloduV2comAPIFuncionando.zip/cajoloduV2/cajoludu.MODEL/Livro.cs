﻿using System;
using System.Collections.Generic;

namespace cajoludu.MODEL;

public partial class Livro
{
    public int Id { get; set; }

    public string? Titulo { get; set; }

    public string? Autor { get; set; }

    public string? Descricao { get; set; }
}
